
import pyttsx3
import speech_recognition as sr

# Initialize the speech engine
engine = pyttsx3.init()

# Define a function to speak
def speak(text):
    engine.say(text)
    engine.runAndWait()

# Initialize recognizer
recognizer = sr.Recognizer()

# Function to listen and recognize speech
def listen():
    with sr.Microphone() as source:
        print("Listening...")
        audio = recognizer.listen(source)
        try:
            command = recognizer.recognize_google(audio)
            print("You said:", command)
            return command
        except sr.UnknownValueError:
            speak("Sorry, I did not understand.")
            return None
        except sr.RequestError:
            speak("Sorry, I am having trouble connecting to the speech service.")
            return None

# Basic functionality
if __name__ == "__main__":
    speak("Hello, I am your electronic daughter.")
    while True:
        command = listen()
        if command:
            if 'stop' in command.lower():
                speak("Goodbye! Take care!")
                break
            else:
                speak(f"You said: {command}")
